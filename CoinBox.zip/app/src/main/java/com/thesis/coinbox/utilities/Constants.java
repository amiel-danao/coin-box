package com.thesis.coinbox.utilities;

public class Constants {
    public final static String USERS_COLLECTION = "users";
}
