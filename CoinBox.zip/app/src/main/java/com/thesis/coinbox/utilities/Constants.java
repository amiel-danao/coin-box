package com.thesis.coinbox.utilities;

public class Constants {
    public final static String USERS_COLLECTION = "users";
    public final static String SAVINGS_COLLECTION = "savings";
}
